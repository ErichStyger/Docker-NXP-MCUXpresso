/*
 * Copyright 2020 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */
  scriptApi.requireScript("codegenerator_utilities.js");
  scriptApi.requireScript("template_engine.js");
/**
 * Function to generate Motor Control (MC_PMSM) configuration code.
 *
 * @param {ComponentInstance} componentInstance
 * @param {FunctionalGroup} functionalGroup
 * @returns {undefined}
 */
function MC_PMSM_Generator(componentInstance, functionalGroup) {
	var coreId = functionalGroup.getCore();
	var modeId = componentInstance.getMode().getId();
	/* Adding license to the begin of the generated code */
	var codeTemplate = componentInstance.readComponentFile("mc_periph_init_h.template");
	var folderPath = "/source/";
	/** Generate file for the selected mode */
	switch (modeId) {
		case "general":	
			/** Load values from component UI and apply them on the template (all template references must be defined) */
			var configSetSettings = new ComponentSettings(componentInstance.getChildById("mc_config"));		//configSet id
			var parameters = configSetSettings.loadParameters("mc_codegenerator");
			/** Generate content from template */
			CustomFileUtils.generateTemplateFile(codeTemplate,"mc_periph_init.h", folderPath, coreId, parameters);
			break;
		default:
			scriptApi.logError("Unknown mode " + modeId);
		return;
	}
}

// register code generation function
CodeGenerator.registerInstanceCodeGenerator(MC_PMSM_Generator);
