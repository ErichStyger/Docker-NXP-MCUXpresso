/**
 *   @file    codegeneratorUtils.js
 *   @version 0.8.1
 *
 *   @brief   SAF top-level configuration generator utils.
 *   @details This file implements top-level configuration generator utils for SAF configuration components.
 *            To be used with Config Tools.
 */
/*==================================================================================================
 *   Project              : MIMX95XX
 *   Platform             : CORTEX-M
 *
 *   SW Version           : 0.8.1
 *
 *   Copyright 2019-2024 NXP
 *   NXP Confidential. This software is owned or controlled by NXP and may only be used strictly
 *   in accordance with the applicable license terms. By expressly accepting
 *   such terms or by downloading, installing, activating and/or otherwise using
 *   the software, you are agreeing that you have read, and that you agree to
 *   comply with and are bound by, such license terms. If you do not agree to
 *   be bound by the applicable license terms, then you may not retain,
 *   install, activate or otherwise use the software.
 ==================================================================================================*/

'use strict';

if (!this.includedModules) {
    this.includedModules = Object.create(null);
}

if (!this.includedModules.utilities) {
    this.includedModules.utilities = true;

    var globalThis = this;

    var utilities = function utilitiesIIFE()
    {
        var properties = {};

        Object.defineProperties(utilitiesIIFE, {
            // Header sections.
            'INCLUDES_SECTION': { enumerable: true, value: 'includes' },
            'CONSTANTS_SECTION': { enumerable: true, value: 'constants' },
            'DEFINES_SECTION': { enumerable: true, value: 'defines' },
            'ENUMS_SECTION': { enumerable: true, value: 'enums' },
            'TYPEDEFS_SECTION': { enumerable: true, value: 'typedefs' },
            'FUNCTION_PROTOTYPES_SECTION': { enumerable: true, value: 'function_prototypes' },
            'COPYRIGHT_YEAR_SECTION': { enumerable: true, value: 'copyright_year' },
            'MISRA_COMMENTS': { enumerable: true, value: 'misra_comments' },

            // C Source sections.
            'MACROS_SECTION': { enumerable: true, value: 'macros' },
            'LOCAL_CONST_SECTION': { enumerable: true, value: 'local_constants' },
            'LOCAL_VARS_SECTION': { enumerable: true, value: 'local_vars' },
            'GLOBAL_CONST_SECTION': { enumerable: true, value: 'global_constants' },
            'GLOBAL_VARS_SECTION': { enumerable: true, value: 'global_vars' },
            'LOCAL_FUNCTION_PROTOTYPES_SECTION': { enumerable: true, value: 'local_function_prototypes' },
            'GLOBAL_FUNCTION_PROTOTYPES_SECTION': { enumerable: true, value: 'global_function_prototypes' },
            'LOCAL_FUNCTIONS_SECTION': { enumerable: true, value: 'local_functions' },
            'GLOBAL_FUNCTIONS_SECTION': { enumerable: true, value: 'global_functions' },    
            'CALLBACK_FUNCTION_SECTION': { enumerable: true, value: 'callback_function_extern' },
            'MISRA_COMMENTS_C': { enumerable: true, value: 'misra_comments' },

            'NEW_LINE': { enumerable: true, value: "\n" },
            'ENABLE_DEBUG': { enumerable: true, value: false },
            'g_CguCache': { enumerable: true, value: {} },

            /// @function logDebugInfo
            /// Log debug information if global variable ENABLE_DEBUG is defined and true.
            /// @param {String} message.
            /// Log debug information if global variable ENABLE_DEBUG is defined and true.
            'logDebugInfo': {
                enumerable: true,
                value: function logDebugInfo(message)
                {
                    // Using PExScriptContextAPI class we log debug information if
                    // global variable ENABLE_DEBUG is defined and true.
                    if (typeof ENABLE_DEBUG === 'undefined' || ENABLE_DEBUG === null || ENABLE_DEBUG === false)
                    {
                        return;
                    }
                    // Just pass the info further.
                    scriptApi.logInfo(message);
                }
            },

            /// @function logDebugInfo
            /// Log debug information if global variable ENABLE_DEBUG is defined and true.
            /// @param {String} message.
            /// Log debug information if global variable ENABLE_DEBUG is defined and true.
            'addInclude': {
                enumerable: true,
                value: function addInclude(hFileName)
                {
                    return "#include \"" + hFileName + "\"\n";
                }
            },

            /// @function addDefine
            /// Generates define directive in C format.
            /// @param {String} symbol name.
            /// @param {String} value.
            /// Generates define directive in C format.
            'addDefine': {
                enumerable: true,
                value: function addDefine(sym, val)
                {
                    return "#define " + sym + "  " + val + "\n";
                }
            },

            /// @function declareVar
            /// Declares a variable in C format.
            /// @param {String} variable type.
            /// @param {String} varibale name.
            /// Declares a variable in C format.
            'declareVar': {
                enumerable: true,
                value: function declareVar(type, sym)
                {
                    return type + " " + sym + ";" + NEW_LINE;
                }
            },

            /// @function setPrioIRQ
            /// Set interrupt prority using cmsis NVIC.
            /// @param {String} interrupt number.
            /// @param {String} interrupt priority.
            /// Set interrupt prority using cmsis NVIC.
            'setPrioIRQ': {
                enumerable: true,
                value: function setPrioIRQ(IRQn, priority)
                {
                    var out = "";
                    out = "  NVIC_SetPriority(" + IRQn +"," + priority +");"+ NEW_LINE;
                    return out;
                }
            },

            /// @function enableIRQ
            /// Enables interrupt using cmsis NVIC.
            /// @param {String} interrupt number.
            /// Enables interrupt using cmsis NVIC.
            'enableIRQ': {
                enumerable: true,
                value: function enableIRQ(IRQn)
                {
                    var out = "";
                    out = "  NVIC_EnableIRQ(" + IRQn +");"+ NEW_LINE;
                    return out;
                }
            },

            /// @function getStructMember
            /// Gets a member of configuration struct.
            /// @param {StructConfig} structure that will be converted.
            /// @param {String} member name.
            /// Gets a member of configuration struct.
            'getStructMember': {
                enumerable: true,
                value: function getStructMember(struct, name)
                {
                    logDebugInfo("[getStructMember] struct: " + struct.getName());
                    var childrens = struct.getChildren();//struct members

                    for(var idx in childrens){
                        var chld = childrens[idx];
                        logDebugInfo("[getStructMember] Child name: " +  chld.getName());
                        if(String(chld.getName()).equals(name)){
                            return chld;
                        }
                    }
                    return null;
                }
            },

            /// @function getImbricatedStructs
            /// Converts an imbricated structure to String using C format.
            /// @param {StructSetting} the structure object that needs to be converted.
            /// @param {String} the type of the C structure.
            /// @param {String} the name of the structure.
            /// @param {String} padding.
            /// Converts an imbricated structure to String using C format.
            'getImbricatedStructs': {
                enumerable: true,
                value: function getImbricatedStructs(struct, name, offset)
                {
                    var out ="";//output string
                    var childrens = struct.getChildren();//struct members

                    out = offset + "." + name + ' = {' + NEW_LINE;
                    for(var idx in childrens){
                        if(Number(idx) !== 0)
                        {
                            out +="," + NEW_LINE;
                        }
                        var chld = childrens[idx];
                        if(chld.getTypeName().equals("struct"))
                        {
                            out += getImbricatedStructs(chld, chld.getName(), offset + "  ");
                        }
                        else
                        {
                            out += offset + "  ." + chld.getName() + ' = ' + chld.getStringValue();
                        }
                    }
                    out += NEW_LINE + offset +"}";
                    return out;
                }
            },

            /// @function getStructAsString
            /// Converts a structure to String using C format.
            /// @param {StructSetting} the structure object that needs to be converted.
            /// @param {String} the type of the C structure.
            /// @param {String} the name of the structure.
            /// Converts a structure to string using C format.
            'getStructAsString': {
                enumerable: true,
                value: function getStructAsString(struct, type, name)
                {
                    var childrens = struct.getChildren();//struct members
                    var out ="";//output string

                    out = "const " + type + " " + name + " = {" + NEW_LINE;

                    for(var idx in childrens){

                        if(Number(idx) !== 0)
                        {
                            out +="," + NEW_LINE;
                        }
                        var chld = childrens[idx];
                        if(chld.getTypeName().equals("struct"))
                        {
                            out += getImbricatedStructs(chld, chld.getName(), "  ");
                        }
                        else
                        {
                            out += "  ." + chld.getName() + ' = ' + chld.getStringValue();
                        }

                    }

                    out += NEW_LINE + "};" + NEW_LINE;

                    return out;
                }
            },

            /// @function getSetting
            /// Gets a setting obj using  an ID.
            /// @param {ConfigSet} UI settings collection.
            /// @param {String} setting ID.
            /// Gets a setting obj using  an ID.
            'getSetting': {
                enumerable: true,
                value: function getSetting(uiConfig, settingId)
                {
                    var childrenList = uiConfig.getChildren();
                    logDebugInfo("[getSetting] settingId: " + settingId);
                    for(var idx in childrenList)
                    {
                        var children = childrenList[idx];
                        logDebugInfo("[getSetting] children.getId(): " + children.getId());

                        if(String(children.getId()).equals(settingId))
                        {
                            logDebugInfo("[getSetting] children: " + children);
                            return children;
                        }
                    }

                    return null;
                }
            },

            /// @function getSettingsValue
            /// Gets a setting value using  an ID.
            /// @param {ConfigSet} UI settings collection.
            /// @param {String} setting ID.
            /// Gets a setting value using  an ID.
            'getSettingsValue': {
                enumerable: true,
                value: function getSettingsValue(uiConfig, settingId)
                {
                    var childrenList = uiConfig.getChildren();
                    logDebugInfo("[getSettingsValue] settingId = " + settingId);

                    for(var idx in childrenList)
                    {
                        var children = childrenList[idx];
                        logDebugInfo("[getSettingsValue] children.getId() = " + children.getId());
                        if(String(children.getId()).equals(settingId))
                        {
                            logDebugInfo("[getSettingsValue] children.getValue() = " + children.getValue());
                            return children.getValue();
                        }
                    }

                    return null;
                }
            },

            /** Class to allow processing component expressions */
            'ExpressionProvider': {
                enumerable: true,
                value: function ExpressionProvider(ASettingConfig)
                {
                    var self = this;
                    var JExpression = Java.type("com.nxp.swtools.common.utils.expression.Expression");

                    self.resolveExpr = function(expr){
                        var ex = JExpression.create(expr);
                        var result = ex.resolve(ASettingConfig.getExpressionContext());
                        return result;
                    };
                }
            },

            'modconf': {
                enumerable: true,
                value: function modconf(functionalGroup, configSetId)
                {
                    var componentConfigSetsList = [];
                    var instancesList = null;

                    instancesList = functionalGroup.getClass().getSimpleName().equals("PeripheralsScriptFunctionalGroup")?
                                    functionalGroup.getComponentInstances() :
                                    functionalGroup.getInstances();

                    for each (var instance in instancesList) {
                        if ((instance.getChild(configSetId) != null) && instance.isEnabled()) {
                            componentConfigSetsList.push(instance.getChild(configSetId));
                        }
                    }
                /*
                    if (componentConfigSetsList.length == 0) {
                        throw new Error("[modconf] Component does not exist (" + configSetId + ")");
                    }
                */
                    return componentConfigSetsList;
                }
            },

            'getChildrenByXPath': {
                enumerable: true,
                value: function getChildrenByXPath(SettingConfig, XPath, FunctionalGroup)
                {
                    var tokens = XPath.split("/");
                    var i = 0;
                    var result;

                    if (FunctionalGroup === undefined) {
                        FunctionalGroup = SettingConfig.getChildContext().getFunctionalGroup();
                    }

                    if (tokens[0] === "") {
                        /* Absolute path detected */
                        result = new java.util.ArrayList(modconf(FunctionalGroup, tokens[1]));
                        i += 2;
                    } else {
                        /* Relative path detected */
                        result = new java.util.ArrayList([SettingConfig]);
                    }

                    if (result.length === 0) {
                        return java.util.Collections.emptyList();
                    }

                    for (i; i < tokens.length; ++i) {

                        if (result.contains(null)) {
                            throw new Error("[getChildrenByXPath] Path does not exist (" + XPath + ")")
                            break;
                        }

                        if (tokens[i] === ".") {
                            continue;
                        } else if (tokens[i] === "..") {
                            result = result.stream()
                                           .map(function(x) {return x.getChildContext().getParent();})
                                           .collect(java.util.stream.Collectors.toList());
                        } else if (tokens[i] === "*"){
                            result = result.stream()
                                           .map(function(x) {return x.getChildren();})
                                           .flatMap(function(x) {return x.stream();})
                                           .collect(java.util.stream.Collectors.toList());
                        } else {
                            result = result.stream()
                                           .map(function(x) {return x.getChildById(tokens[i]);})
                                           .collect(java.util.stream.Collectors.toList());
                        }
                    }

                    return result;
                }
            },

            'getChildrenByASPath': {
                enumerable: true,
                value: function getChildrenByASPath(SettingConfig, ASPath, FunctionalGroup)
                {
                    var tokens = ASPath.split("/");
                    var result;

                    if (FunctionalGroup === undefined) {
                        FunctionalGroup = SettingConfig.getChildContext().getFunctionalGroup();
                    }

                    if (tokens[0] === "") {
                        /* Absolute path detected */
                        result = new java.util.ArrayList(FetchStripArPackages(FunctionalGroup, tokens));
                    } else {
                        /* Relative path detected */
                        //result = new java.util.ArrayList([SettingConfig]);
                        throw new Error("[getChildrenByASPath] Relative paths are not supported")
                    }

                    if (result.length === 0) {
                        return java.util.Collections.emptyList();
                    }

                    for (var i = 2; i < tokens.length; ++i) {
                        var newResult = new java.util.ArrayList();

                        if (newResult.contains(null)) {
                            throw new Error("[getChildrenByASPath] Path does not exist (" + ASPath + ")")
                            break;
                        }

                        for each (var Setting in result) {
                            var nextSetting = Setting.getChildById(tokens[i]);

                            if (nextSetting === null) {
                                throw new Error("[getChildrenByASPath] Cannot find child '" + tokens[i] + "' of parent " + Setting);
                            }

                            if (nextSetting.getTypeName() === "array") {
                                for each (var child in nextSetting.getChildren()) {
                                    if (child.isAvailable()) {
                                        newResult.add(child);
                                    }
                                }
                            } else {
                                if (nextSetting.isAvailable()) {
                                    newResult.add(nextSetting);
                                }
                            }
                        }

                        result = newResult;
                    }

                    return result;
                }
            },

            'FetchStripArPackages': {
                enumerable: true,
                value: function FetchStripArPackages(functionalGroup, ASPathTokens)
                {
                    /* 
                        Examples:
                        /AUTOSAR/EcucDefs/Eth
                        /TS_T40D11M9I0R0/Eth
                    */

                    /* StMD Reference */
                    if ((ASPathTokens[1] === "AUTOSAR") && (ASPathTokens[2] === "EcucDefs")) {
                        ASPathTokens.splice(1,2);   // Mutates the original argument
                        return modconf(functionalGroup, ASPathTokens[1]);
                    }

                    /* VSMD Reference */
                    for (var i = 1; i < ASPathTokens.length; ++i) {
                        var componentConfigSetsList = modconf(functionalGroup, ASPathTokens[i]);

                        if (componentConfigSetsList.length != 0) {
                            var retComponentConfigSetsList = [];
                            var originArPackagePath = ASPathTokens.slice(1, i).join('/');

                            for (var j = 0; j < componentConfigSetsList.length; ++j) {
                                var targetArPackagePath = componentConfigSetsList[j].getChildContext().getParent().getOptionValue("path");
                                if (originArPackagePath === targetArPackagePath) {
                                    retComponentConfigSetsList.push(componentConfigSetsList[j]);
                                }
                            }

                            ASPathTokens.splice(1,i-1); // Mutates the original argument
                            return retComponentConfigSetsList;
                        }
                    }

                    return [];
                }
            },

            'StripArPackages': {
                enumerable: true,
                value: function StripArPackages(functionalGroup, ASPathTokens)
                {
                    var configSetsList = [];
                    for (var i = 1; i < ASPathTokens.length; ++i) {
                        configSetsList = modconf(functionalGroup, ASPathTokens[i]);
                        if (configSetsList.length != 0) {
                            break;
                        }
                    }

                    ASPathTokens.splice(1,i-1); // Mutates the original argument
                }
            },

            'deref': {
                enumerable: true,
                value: function deref(DynamicEnumSetting, SkipNullError)
                {
                    /*
                        Example
                        Descr: /EcuC_1/MyEcuC/EcucPartitionCollection_0/EcucPartition_0
                        Def:            /EcuC/EcucPartitionCollection/EcucPartition
                    */
                    var functionalGroup = DynamicEnumSetting.getChildContext().getFunctionalGroup();
                    if (functionalGroup === null) {
                        throw new Error("[deref] Cannot retrieve the child's functional group (" + DynamicEnumSetting.getChildContext() + ")");
                        return null;
                    }

                    var itemsExprString = DynamicEnumSetting.getModelData().getItemsExprString();
                    var refMatcher      = java.util.regex.Pattern.compile(".*?getChildrenByASPath\\(`(.*?)`\\)").matcher(itemsExprString);

                    // For ECUC-REFERENCE-DEF, tokensDefArr.length == 1
                    // For ECUC-CHOICE-REFERENCE-DEF, tokensDefArr.length > 1
                    var tokensDefArr    = []
                    while (refMatcher.find()) {
                        tokensDefArr.push(refMatcher.group(1).split("/"))
                    }
                    if (tokensDefArr.length === 0) {
                        throw new Error("[deref] Could not retrieve reference destination path for " + DynamicEnumSetting)
                    }

                    var tokensDescr = DynamicEnumSetting.getValue().split("/");
                    var refSetting  = null;

                    /*
                        In AUTOSAR, only getChildByName should be used to retrieve nodes.
                        If the referenced shortName cannot be found, then the node doesn't
                        exist in the current configuration.
                    */
                    for (var i = 0; (i < tokensDefArr.length) && (refSetting === null); ++i) {
                        refSetting = functionalGroup.getChildById(tokensDescr[1]);

                        StripArPackages(functionalGroup, tokensDefArr[i]);
                        for (var j = 1; (j < tokensDefArr[i].length) && (refSetting != null); ++j) {
                            refSetting = getChildByName(refSetting.getChildById(tokensDefArr[i][j]), tokensDescr[j+1]);
                            if (refSetting && !refSetting.isAvailable()) {
                                throw new Error("[deref] Reference is not available (" + DynamicEnumSetting.getChildContext() + ")");
                                return null;
                            }
                        }
                    }

                    if (refSetting === null) {
                        if (!SkipNullError) {
                            throw new Error("[deref] Reference does not exist (" + DynamicEnumSetting.getChildContext() + ")");
                        }
                        return null;
                    }

                    return functionalGroup.getChildById(tokensDescr[1] + "." + refSetting.getId());
                }
            },

            'getChildByName': {
                enumerable: true,
                value: function getChildByName(SettingConfig, Name)
                {
                    /* SettingConfig is either ArrayConfig or StructSetting or ConfigSetConfig */
                    if (SettingConfig.getTypeName() === "array") {
                        for each (var child in SettingConfig.getChildren()) {
                            var NameSetting = child.getChildById("Name");
                            if (NameSetting === null) {
                                throw new Error("[getChildByName] Container " + child.getChildContext().getComponentInstanceConfig().getId() + "." + child.getId() + 
                                                " does not have a <string> field with id='Name'");
                            }
                            if (NameSetting.getValue() === Name) {
                                return child;
                            }
                        }
                    }
                    else if ((SettingConfig.getTypeName() === "struct") || (SettingConfig.getTypeName() === "config_set")) {
                        var NameSetting = SettingConfig.getChildById("Name");
                        if (NameSetting === null) {
                            throw new Error("[getChildByName] Container " + SettingConfig.getChildContext().getComponentInstanceConfig().getId() + "." + SettingConfig.getId() + 
                                            " does not have a <string> field with id='Name'");
                        }
                        if (NameSetting.getValue() === Name) {
                            return SettingConfig;
                        }
                    }

                    return null;
                }
            },

            'order': {
                enumerable: true,
                value: function order(SettingConfigList, ChildId)
                {
                    if (ChildId == null) {
                        return SettingConfigList.stream()
                                                .sorted(function(x,y) {return x.getValue() - y.getValue();})
                                                .collect(java.util.stream.Collectors.toList());
                    } else {
                        return SettingConfigList.stream()
                                                .sorted(function(x,y) {return x.getChildById(ChildId).getValue() - y.getChildById(ChildId).getValue();})
                                                .collect(java.util.stream.Collectors.toList());
                    }
                }
            },

            'refvalid': {
                enumerable: true,
                value: function refvalid(DynamicEnumSetting)
                {
                    return (DynamicEnumSetting.getValue() != "") && (deref(DynamicEnumSetting, true) != null);
                }
            },

            'exists': {
                enumerable: true,
                value: function exists(OptionalSettingConfig)
                {
                    if (OptionalSettingConfig.getTypeName() != "array") {
                        throw new TypeError("[exists] The setting is not an optional element (" + OptionalSettingConfig + ")");
                        return null;
                    }

                    return (OptionalSettingConfig.getChildren().length != 0);
                }
            },

            'opt': {
                enumerable: true,
                value: function opt(OptionalSettingConfig)
                {
                    if (OptionalSettingConfig.getTypeName() != "array") {
                        throw new TypeError("[opt] The setting is not an optional element (" + OptionalSettingConfig + ")");
                        return null;
                    }

                    var SettingConfig = OptionalSettingConfig.getChild(0);
                    if (SettingConfig === null) {
                        throw new Error("[opt] The optional element does not exist (" + OptionalSettingConfig +")");
                        return null;
                    }

                    return SettingConfig;
                }
            },

            'getName': {
                enumerable: true,
                value: function name(SettingConfig)
                {
                    var NameSetting = SettingConfig.getChildById("Name");
                    var Name = "";

                    if (NameSetting === null) {
                        throw new Error("[name] Name does not exist (" + SettingConfig + ")");
                    } else {
                        Name = NameSetting.getValue();
                    }

                    return Name;
                }
            },

            'getParent': {
                enumerable: true,
                value: function getParent(SettingConfig, UpLevels)
                {
                    while (UpLevels--) {
                        SettingConfig = SettingConfig.getChildContext().getParent();
                    }

                    return SettingConfig;
                }
            },

            'index': {
                enumerable: true,
                value: function index(SettingConfig)
                {
                    var SettingConfigParent = SettingConfig.getChildContext().getParent();
                    if (SettingConfigParent.getTypeName() === "array") {
                        return SettingConfigParent.getChildren().indexOf(SettingConfig);
                    } else {
                        throw new Error("[index] The setting is not a list member (" + SettingConfig + ")");
                    }
                }
            },

            'hasExclusiveOwnership': {
                enumerable: true,
                value: function hasExclusiveOwnership(peripheralName, functionalGroup)
                {
                    var owners = 0;

                    for each (var instance in functionalGroup.getComponentInstances()) {
                        if (instance.isEnabled()) {
                            for each (var configSet in instance.getConfigSets()) {
                                var peripheralList = configSet.getChildById('used_peripherals');
                                if (peripheralList != null) {
                                    if (peripheralList.getValue().indexOf(peripheralName) != -1) {
                                        ++owners;
                                    }
                                }
                            }
                        }
                    }

                    if (owners == 0) {
                        throw new Error("[hasExclusiveOwnership] No component has ownership over " + peripheralName);
                    }

                    return (owners == 1);
                }
            },

            'containsValue': {
                enumerable: true,
                value: function containsValue(ArrayConfig, SettingValue)
                {
                    for each (element in ArrayConfig) {
                        if (element.equals(SettingValue)) {
                            return true;
                        }
                    }

                    return false;
                }
            },

            'useFgInfix': {
                enumerable: true,
                value: function useFgInfix()
                {
                    if (g_CguCache["PBVS"] === undefined) {
                        var SystemModel = scriptApi.getProfile().getComponentConfiguration("system").getGlobalConfigSet();
                        g_CguCache["PBVS"] = 
                            (SystemModel.getChildById("ComponentGenerationMethod").getValue() == "FunctionalGroups")
                            ||
                            (SystemModel.getChildById("vHasPostBuildVariants").getValue() == true);
                    }

                   return g_CguCache["PBVS"];
                }
            },
        });

        for (var p in utilitiesIIFE) {
            /* Export this module's properties to the global object */
            Object.defineProperty(globalThis, p, Object.getOwnPropertyDescriptor(utilitiesIIFE, p));
            /* Export this module's properties to the namespace object */
            Object.defineProperty(properties, p, Object.getOwnPropertyDescriptor(utilitiesIIFE, p));
        }

        /* Edge case: avoid javax.script.ScriptException: TypeError: Cannot redefine property "name" of function utilitiesIIFE() */
        Object.defineProperty(globalThis, 'name', Object.getOwnPropertyDescriptor(utilitiesIIFE, 'getName'));

        return properties;
    }();
}
