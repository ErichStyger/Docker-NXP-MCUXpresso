/*
 * SAF code generator
 * 
 * Copyright 2017-2024 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */
 
 
scriptApi.requireScript("codegeneratorUtils.js");
scriptApi.requireScript("saf_templatingengine.js");


var CGFilter = (function() {
    var exportedArgs         = new java.util.ArrayList(
                                scriptApi.getUtils().getExportedArgs() || []
                               );
    var exportedComponentIds = new java.util.ArrayList(
                                scriptApi.getUtils().getExportedComponentIds() || []
                               );

/*    java.util.stream.IntStream
                    .range(0, exportedArgs.size())
                    .forEach(function(i) exportedArgs[i] = exportedArgs[i].toLowerCase());*/
                    
		for (let i = 0; i < exportedArgs.size(); i++) {
		    exportedArgs[i] = exportedArgs[i].toLowerCase();
		}     
/*    java.util.stream.IntStream
                    .range(0, exportedComponentIds.size())
                    .forEach(function(i) exportedComponentIds[i] = exportedComponentIds[i].toLowerCase());*/
                    
		for (let i = 0; i < exportedArgs.size(); i++) {
		    exportedComponentIds[i] = exportedComponentIds[i].toLowerCase();
		}     
    // Exporting ECPDs is a special case. Those should only be generated on-demand.
    var exportEcpd = (exportedArgs.indexOf("ecpd") != -1);

    var exportExtension = function(ExtensionStr) {
        return (exportedArgs.size() == 0) ||
               (exportedArgs.indexOf(ExtensionStr.toLowerCase()) != -1);
    }

    var exportComponent = function(CompIdStr) {
        return (exportedComponentIds.size() == 0) ||
               (exportedComponentIds.indexOf(CompIdStr.toLowerCase()) != -1);
    }

    return {"exportEcpd"     : exportEcpd,
            "exportExtension": exportExtension,
            "exportComponent": exportComponent};
})();

 
var generatedFilesList = [];
var tEngineSAF = new SAF_TemplatingEngine();

function generateFile(inputFileName, options, outputFileName, outputFolder) {
    var extension = inputFileName.slice(inputFileName.indexOf(".") + 1, inputFileName.length);

    if (CGFilter.exportExtension(extension)) {
        var outputFileName = (outputFileName === undefined)? inputFileName : outputFileName;
        //the required global settings are not specified for global config set
        // var variantName = useFgInfix()? options[1].getName() + '_' : '';
        //var variantName = options[1].getName() + '_';
        var variantName = '';

        var sliceIndex = (outputFileName.indexOf("PBcfg") != -1)? outputFileName.indexOf("PBcfg") : outputFileName.indexOf("LTcfg");
        if (sliceIndex != -1) {
            outputFileName = outputFileName.slice(0, sliceIndex) + variantName + outputFileName.slice(sliceIndex);
        }

        if (outputFolder === undefined) {
            if (inputFileName.indexOf(".c") != -1) {
                outputFolder = "/generate/src/";
            } else if (inputFileName.indexOf(".h") != -1) {
                outputFolder = "/generate/include/";
            } else {
                scriptApi.logError("[generateFile] Unknown file extension (" + inputFileName + "). Please provide the output folder name!");
            }
        }

        if (generatedFilesList.indexOf(outputFileName) === -1) {
            var template = options[0].getChildContext().getComponentInstanceConfig().readComponentFile(inputFileName);
            var coreId = options[0].getChildContext().getFunctionalGroup().getCore();

            generatedFilesList.push(outputFileName);
            scriptApi.logInfo("[CODEGEN] Generating file \"" + outputFileName + "\"");
            new OutputFile(outputFolder + outputFileName, coreId).close(tEngineSAF.generate(template, options));
        }
    }
};

/* 
 * SAF codegenerator function
 */
 
function createTemplatesPerComponent(profile, postBuildVariant, variantsList, componentInstanceConfig) {
/*
    var yamlProfileContent  = "";
    var yamlInstanceContent = "";

    //Yaml code
    if (profile.getYaml() != null) {
      yamlProfileContent += profile.getYaml() + '\n';
    }
*/
    if (componentInstanceConfig.getError() === null) {
/*
        //Yaml code
        if (componentInstanceConfig.getYaml() != null) {
            yamlInstanceContent = componentInstanceConfig.getYaml() + '\n';
        }
*/
        var configSets = componentInstanceConfig.getChildren();
        for each (var configSet in configSets) {
            var mustGenTemplates = getSettingsValue(configSet, configSet.getName() + ".generate_templates");

            if (mustGenTemplates === "true") {
                try {
                    var codeGenFile = getSettingsValue(configSet, configSet.getName() + ".codegen_file");
                    if (codeGenFile != null) {
                        scriptApi.requireScript("../" + componentInstanceConfig.getComponentTypeId() + "/" + codeGenFile);
                        var codeGenName   = getSettingsValue(configSet, configSet.getName() + ".codegen_class");
                        var codeGenObject = new Function("return " + codeGenName)();
                        codeGenObject(configSet, postBuildVariant, variantsList, componentInstanceConfig);
                    }
                }
                catch (err)
                {
                    scriptApi.logError(err);
                }
            }
        }
    }
}


/* 
 * END of the SAF codegenerator function
 */

