/*
 * Copyright 2018 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */
/*
 * SAF Templating engine
 * Usage: Use '$' to separate simple text from options. Use <code></code> to separate options from a code.
 *
 * Usage example:
 * var template = 'This text will be printed as is.\\n${ text }$\\nCode example:${<code>\
 * for(var i=0; i<5; i++){\
 *     </code>}$\\nIteration #${ i <code>\
 * }\
 * </code>}$';
 *    var options = {text : 'This text will be inserted as an option.'};
 *    var finalText = templateEngine(template, options);
 */
SAF_TemplatingEngine = function() {
    var self = this;
    self.generate = function(template, options){
        var outputCode = 'var r=[];\n';

        // split code into simple text and option with code sections
        // \s\S to match all chars including white space
        var splitTemplate = template.split(/(\[\![\s\S]*?\!\])/);
        var prevPart = "";
        // create a code based on the template
        splitTemplate.forEach(function(part){
            if(part.charAt(0) === '[' && part.charAt(1) === '!'){
                // remove '![' and '!]' and split part into options and code sections
                var splitPart = part.slice(2, -2).split(/(<code>[\s\S]*?<\/code>)/);
                splitPart.forEach(function(option){
                    if(option.startsWith("<code>")){
                        // remove <code> and </code>
                        option = option.replace(/<code>[ \t]*(?!\S)(\r\n|\r|\n)/, "");
                        option = option.replace("<code>", "");
                        option = option.slice(0, -7).split(/(\$[\s\S]*?\$)/);

                        option.forEach(function(suboption){
                            if(suboption.charAt(0) === '$'){
                                suboption = suboption.slice(1, -1);
                                outputCode += 'r.push(' + suboption + ');';
                            }else{
                                suboption = suboption.replace(/(\\?)(\r\n|\r|\n)/g, "\\n\\$2");
                                outputCode += 'r.push(\'' + suboption + '\');';
                            }
                        });
                    }else{
                        outputCode += option;
                    }
                });
            }else{
                // preserve line breaks when the template is read from a file
                part = part.replace(/(\\?)(\r\n|\r|\n)/g, "\\n\\$2");
                if (prevPart.slice(-2) === "!]") {
                    part = part.replace(/^\s*(\\r\\n|\\r|\\n)/, "");
                }
                outputCode += 'r.push(\'' + part + '\');';
            }
            
            prevPart = part;
        });
        outputCode += '\nreturn r.join("");';

        try {
            // execute assambled code and return the result
            return new Function('"use strict";\n' + outputCode).apply(options);
        } catch (error) {
            if (error.stack) {
                // Javascript exception
                scriptApi.logError(error.stack);
            } else {
                // Java exception
                scriptApi.logError(error + "\n" + java.util.Arrays.toString(error.getStackTrace()).replaceAll(",", "\n"));
            }
        }
    };
};
