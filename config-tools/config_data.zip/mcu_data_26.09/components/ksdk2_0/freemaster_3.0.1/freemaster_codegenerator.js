/*
 * Copyright 2021 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */
  scriptApi.requireScript("codegenerator_utilities.js");
  scriptApi.requireScript("template_engine.js");
/**
 * Function to generate FreeMASTER application code.
 *
 * @param {ComponentInstance} componentInstance
 * @param {FunctionalGroup} functionalGroup
 * @returns {undefined}
 */
function FREEMASTERgenerator(componentInstance, functionalGroup) {
	var coreId = functionalGroup.getCore();
	var modeId = componentInstance.getMode().getId();
	/* Adding license to the begin of the generated code */
	var codeTemplate = componentInstance.readComponentFile("freemaster_cfg_h.template");
	var folderPath = "/source/";
	var generatedFolder = "/source/generated/";
	/** Generate file for the selected mode */
	switch (modeId) {
		case "general":	
			/** Load values from component UI and apply them on the template (all template references must be defined) */
			var configSetSettings = new ComponentSettings(componentInstance.getChildById("freemaster_config"));		//configSet id
			var parameters = configSetSettings.loadParameters("freemaster_codegenerator");
			/** Generate content from template */
			CustomFileUtils.generateTemplateFile(codeTemplate,"freemaster_cfg.h", folderPath, coreId, parameters);
			/** USB CDC example generation **/ 
			var generateUsbCdc = configSetSettings.loadValue("generalConfig.usbConfig.enableUsbCodeGeneration");
			if(generateUsbCdc){
				var hFileTemplate = componentInstance.readComponentFile("freemaster_usb_h.template");
				var cFileTemplate = componentInstance.readComponentFile("freemaster_usb_c.template");
				var usbParameters = configSetSettings.loadParameters("freemaster_usb_codegenerator");
				/** Generate content from templates */
				CustomFileUtils.generateTemplateFile(hFileTemplate,"freemaster_usb.h", generatedFolder, coreId, usbParameters);
				CustomFileUtils.generateTemplateFile(cFileTemplate,"freemaster_usb.c", generatedFolder, coreId, usbParameters);
			}
			break;
		default:
			scriptApi.logError("Unknown mode " + modeId);
		return;
	}
}

// register code generation function
CodeGenerator.registerInstanceCodeGenerator(FREEMASTERgenerator);
