/*
 * Copyright 2018-2020 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */
/**
 * Function to get processor specific information used in USB templates
 *
 * @param {String} pn MCU part number
 * @param {String} series MCU series
 * @param {String} peripheral Name of the selected peripheral
 * @returns {Object} parameters specific to the MCU
 */
function getProcessorSpecifics(pn, series, peripheral) {
	function getLpcControlerName(peripheral) {
		var controllerName = [];
		
		if (peripheral === "USB0" || peripheral === "USB") {
			controllerName = ["lpc", "ip3511", "fs"];
		} else if (peripheral === "USBFSH") {
			controllerName = ["ohci"];
		} else if (peripheral === "USBHSD") {
			controllerName = ["lpc", "ip3511", "hs"];
		} else if (peripheral === "USBHSH") {
			controllerName = ["ip3516", "hs"];
		} else {
			scriptApi.logError("Peripheral " + peripheral + " is not supported by USB component on " + series + " MCUs.");
		}
		
		return controllerName;
	}
	
	var specifics = {
		mk64 : false,
		kinetis : false,
		scgClockSel : false,
		lpc54xxx : false,
		lpc55xx : false,
		lpcUsbPhy : false,
		iMxRT1xxx : false,
		iMxRT6xx : false,
		iMxRT5xx : false,
		iMxRT7xx : false,
		pn76xx : false,
		mcxn9xx_5xx : false,
		mcxn2xx : false,
		mcxa1xx : false,
		mcxa2ts : false,
		RW61x : false,
		UsbWakeClkId : "",
		UsbPllClkId : "",
		iMxRTUsbCount : 2, 
		iMxRTUsbClockFreq : false,
		controllerName : "",
		phyPeripheralName : "",
		controllerIdx : 0,
    dedicatedRam : false,
    systickGetFreqFunctionCall : "CLOCK_GetFreq(kCLOCK_CoreSysClk)"
	};

	switch(series) {
		case "Kinetis K32L":
			specifics.kinetis = true;
			specifics.controllerName = "khci";
			break;
		case "Kinetis K":
		// fall-through
		case "Kinetis L":
		case "MCX MCXC":
			specifics.kinetis = true;
			if (peripheral === "USB0") {
				specifics.controllerName = "khci";
			} else if (peripheral === "USBHS") {
				specifics.controllerName = "ehci";
			} else {
				scriptApi.logError("Peripheral " + peripheral + " is not supported by USB component on " + series + " MCUs.");
			}
			break;
		case "LPC LPC54000":
			specifics.lpc54xxx = true;
			specifics.dedicatedRam = true;
			specifics.controllerName = getLpcControlerName(peripheral);
			break;
		case "LPC LPC5500":
			specifics.lpc55xx = true;
      if ((pn != "LPC55S36") && (pn != "LPC5534") && (pn != "LPC5536")) {
			  specifics.dedicatedRam = true;
	    }
			specifics.controllerName = getLpcControlerName(peripheral);
			break;
		case "i.MX RT":
			if (peripheral === "USB" || peripheral === "USB0" || peripheral === "USB1" || peripheral === "USB2" || peripheral === "USB_OTG1" || peripheral === "USB_OTG2") {
				specifics.controllerName = "ehci";
				specifics.iMxRT1xxx = true;
			} else {
				specifics.iMxRT6xx = true;
				specifics.dedicatedRam = true;
				// RT6xx has LPC USB peripherals
				specifics.controllerName = getLpcControlerName(peripheral);
			}
			
			if (peripheral === "USB2") {
				specifics.controllerIdx = 1;
			}
			break;
		case "MCX MCXN":
			if (peripheral === "USBHS1__USBC") {
				specifics.controllerName = "ehci";
				if ((pn == "MCXN236") || (pn == "MCXN235")) {
  				specifics.mcxn2xx = true;
				} else {
  				specifics.mcxn9xx_5xx = true;
				}
				specifics.phyPeripheralName = "USBHS1_PHY_DCD";
			} else if (peripheral === "USBFS0") {
				specifics.controllerName = "khci";
				specifics.mcxn9xx_5xx = true;
			} else {
			  scriptApi.logError("MCU series " + series + ", " + peripheral + " is not supported by USB component.");
			}
			break;
		case "PN76 PN76xx":
			specifics.pn76xx = true;
			specifics.controllerName = getLpcControlerName(peripheral);
			break;
		case "MCX MCXA":
			if (peripheral === "USB0") {
				specifics.controllerName = "khci";
				specifics.mcxa1xx = true;
            } else if(peripheral === "USBHS1"){
                specifics.controllerName = "ehci";
				specifics.mcxa2ts = true;
				specifics.phyPeripheralName = "USBHS1_PHY";
				specifics.UsbPllClkId = "USB_PLL_clock";
			} else {
			  scriptApi.logError("MCU series " + series + ", " + peripheral + " is not supported by USB component.");
			}
			break;
		case "RW RW61x":
				specifics.controllerName = "ehci";
				specifics.RW61x = true;
				specifics.systickGetFreqFunctionCall = "CLOCK_GetCoreSysClkFreq()";
			break;
		default:
			scriptApi.logError("MCU series " + series + " is not supported by USB component.");
			break;
	}
	
	var nameRegex = /([a-zA-Z]+\d+).*/;
	nameMatch = nameRegex.exec(pn);

	switch (nameMatch[1])
	{
		case "LPC5534":
		case "LPC5536":
		    specifics.lpcUsbPhy = true;
		    break;
		case "LPC55":
		    if (pn == "LPC55S36"){
		        specifics.lpcUsbPhy = true;
		    }
		    break;
		case "MK64":
			specifics.mk64 = true;
			break;
        case "MIMXRT1011":
        case "MIMXRT1015":
        case "MIMXRT1024":
		case "MIMXRT1021":
		case "MIMXRT1041":
		case "MIMXRT1042":
			specifics.iMxRTUsbCount = 1;
			break;
		case "MIMXRT1165":
		case "MIMXRT1166":
		case "MIMXRT1171":
		case "MIMXRT1172":
		case "MIMXRT1173":
		case "MIMXRT1175":
		case "MIMXRT1176":
		case "MIMXRT1181":
		case "MIMXRT1182":
		case "MIMXRT1187":
		case "MIMXRT1189":
			specifics.iMxRTUsbClockFreq = true;
			break;
		case "MIMXRT595":
		case "MIMXRT555":
		case "MIMXRT533":
			specifics.iMxRT5xx = true;
		    break;
	    case "MIMXRT735":
		case "MIMXRT758":
		case "MIMXRT798":
			specifics.iMxRT7xx = true;
			specifics.iMxRT1xxx = false;
			specifics.UsbWakeClkId = "USB_WAKE_CLK";
			if (peripheral === "USB1") {
				specifics.controllerIdx = 1;
			}
		    break;
		case "K32":
		    if (pn == "K32L2A31xxxxA" || pn == "K32L2A41xxxxA"){
		        specifics.scgClockSel = true;
		    }
			break;
	}
	
	return specifics;
}

// The getControllerName function returns the ID (lowercase) of the controller name for validation of supported controllers in the usb.component
function getControllerName(pn, series, peripheral) {
  var specifics = getProcessorSpecifics(pn, series, peripheral);
  // if the string type is returned
  if (specifics.controllerName.constructor !== Array) {
	  return specifics.controllerName.toLowerCase();
	}
  return specifics.controllerName.join("").toLowerCase();
}

// The getPhyPeripheralName function returns the peripheral name of PHY controller
function getPhyPeripheralName(pn, series, peripheral) {
  var specifics = getProcessorSpecifics(pn, series, peripheral);
  return specifics.phyPeripheralName;
}

//The getUsbWakeClkId function returns id of UsbWakeClk if it has one, otherwise returns empty string
function getUsbWakeClkId(pn, series, peripheral) {
    var specifics = getProcessorSpecifics(pn, series, peripheral);
    return specifics.UsbWakeClkId;
}

//The getUsbPllClkId function returns id of UsbPllClk if it has one, otherwise returns empty string
function getUsbPllClkId(pn, series, peripheral) {
    var specifics = getProcessorSpecifics(pn, series, peripheral);
    return specifics.UsbPllClkId;
}

