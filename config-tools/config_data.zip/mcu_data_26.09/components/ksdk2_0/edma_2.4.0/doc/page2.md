##Use cases

This section describes use cases for the implementation of the DMA transfer using the *Transactional* mode and both *Non-transactional* modes.
This introduction describes general component configuration use cases:  
- Transfer types - Configuration of DMA transfer mode regarding to the device type (Memory/Peripheral).
- TCD configuration - General component configuration of eDMA transfer control descriptor (TCD).

###Transfer types

The eDMA transfer source and destination exist in two types: memory or peripheral. The specific 
type affects the source and destination offset settings of the TCD structure. In case of memory the offset value needs to be set, otherwise the new
data rewrite the old data in the memory. The offset values in examples are represented by data block size of used source/destination address.  
Settings examples for the following transfer types:  

**Memory To Memory**
- Destination offset: `sizeof(dstAddr[0])` *- Destination address data block size*
- Source offset: `sizeof(srcAddr[0])` *- Source address data block size*
  
**Memory To Peripheral**
- Destination offset: `0`
- Source offset: `sizeof(srcAddr[0])`
  
**Peripheral To Memory**
- Destination offset: `sizeof(dstAddr[0])`
- Source offset: `0`
  
**Peripheral To Peripheral**
- Destination offset: `0`
- Source offset: `0`
  

###TCD configuration

Transfer control descriptors can be configured in all supported modes, but the configuration is slightly different.
In *transactional* and *non-transactional (API functions)* modes a transfer structure (`edma_transfer_config_t`) is configured. 
This structure configures the source and destination transfer attributes. Together with the use of API functions these modes provide partial 
configuration of the TCD registers.  
For full and direct configuration of TCDs use the *non-transactional (TCD structures)* API mode, which configures the whole TCD at once with direct
write to TCD registers. A TCD structure (`edma_tcd_t`) is configured in this mode.  
This example showcases a general TCD configuration in the framework of a *non-transactional (TCD structures)* mode. Other modes use equivalent settings 
to configure the TCD partially.

The transfer control descriptor configuration of eDMA channel for basic transfer:

**Configure component as follows:**

- **TCD ID:** `CH0_TCD0` (required, user-defined)  
- **Source address configuration**  
    - **Data size [Byte]:** `4` (required, user-selected)  
    - **Address expression:** `&srcAddr0[0]` (required, user-defined)  
    - **External definition:** `uint32_t srcAddr0[]` (optional, defined in user code)  
    - **Offset expression:** `sizeof(srcAddr[0])` (user-defined)  
    - **External definition** (optional, user-defined)  
    - **Modulo:** `Disabled modulo` (optional, user-selected)  
- **Destination address configuration**  
    - **Data size [Byte]:** `4` (required, user-selected)  
    - **Address expression:** `&dstAddr0[0]` (required, user-defined)  
    - **External definition:** `uint32_t dstAddr0[]` (optional, defined in user code)  
    - **Offset expression:** `sizeof(dstAddr[0])` (user-defined)  
    - **External definition** (optional, user-defined)  
    - **Modulo:** `Disabled modulo` (optional, user-selected)  
- **Minor loop configuration**  
    - **Minor loop transfer [Byte]:** `16` (required, user-selected, e.g. minor loop of 4x4 Bytes)  
    - **Minor loop offset:** (optional) `Disabled`  
    - **Minor loop link enable:** `disabled` (optional)  
    - **Bandwidth control:** `No eDMA engine stalls` (optional)  
- **Major loop configuration**  
    - **Major loop count:** `1` (required, user-defined)  
    - **Source last address adjustment:** `-16` (optional, user-defined, e.g. 16-Byte for 4x[*Data size*])  
    - **Destination last address adjustment:** `-16` (optional, user-defined, e.g. 16-Byte for 4x[*Data size*])  
    - **Major loop link enable:** `disabled` (optional)  
    - **Auto stop request:** (optional, depends on DMA request)  
- **Scatter-gather configuration** (optional)  
    - **Scatter-gather enable:** `disabled`  
- **Interrupt configuration** (optional)  
    - **Interrupt sources:** Major count half completion `disabled` Major count completion `disabled`  

Copy the following code into the variables section of your application code:  
*Note*: You can use **Definition template** copy to clipboard button if you modified some of the expressions.

---

>  
    /* Example of buffers definitions by user */
>    
    /* DMA0 TCD CH0_TCD0 source address */
    AT_NONCACHEABLE_SECTION_ALIGN_INIT(uint32_t srcAddr[4U], kEDMA_TransferSize4Bytes) = {0x01, 0x02, 0x03, 0x04};
    /* DMA0 TCD CH0_TCD0 destination address */
    AT_NONCACHEABLE_SECTION_ALIGN_INIT(uint32_t dstAddr[4U], kEDMA_TransferSize4Bytes) = {0x00, 0x00, 0x00, 0x00};

---