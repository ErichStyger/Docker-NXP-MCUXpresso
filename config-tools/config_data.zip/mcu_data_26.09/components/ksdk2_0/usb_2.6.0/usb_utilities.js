/*
 * Copyright 2016-2019 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */
			
/**
 * Creates a identifier from provided name with specified case.
 *
 * @param {String} identifier from the settings 
 * @param {String} requestedCase in CamelCase
 * @returns {String} string with requested case
 */
function composeString(nameStr, requestedCase) {
  var output = "";
  var words = [];
	var suffixes = nameStr.trim().split(/[_\s]/);
	for (let i = 0; i < suffixes.length; ++i) {
		if (!suffixes[i].isEmpty()) {
			words.push(suffixes[i]);
		}
	}
	if (words.constructor !== Array) {
		words = [words];
	}
	switch (requestedCase) {
		case "UpperCase":
			output = words.join("").toUpperCase();
			break;
		case "LowerCase":
			output = words.join("").toLowerCase();
			break;
		case "CamelCase":
			words.forEach(function (word) {
				word = "" + word;
				output += word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
			});
			break;
		case "LowerCamelCase":
			output = composeString(nameStr, "CamelCase");
			output = output.charAt(0).toLowerCase() + output.slice(1);
			break;
		case "LowerSnakeCase":
			output = words.join("_").toLowerCase();
			break;
		case "SnakeCase":
			output = words.join("_").toUpperCase();
			break;
	}
	return output;
}