/*
 * Copyright 2024 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */

var FileType = Java.type("com.nxp.swtools.utils.scripting.api.IOutWriterFactory.FileType");

// This object opens a file and writes into the file
OutputFile = function (fileName, coreId) {
    var self = this;

    // name of the generated file
    self.fileName = fileName;

    // output stream
    self.output = scriptApi.createFile(fileName, coreId, FileType.TEXT);

    // write file content and 'close' file object
    self.close = function (content) {
        self.output.write(content);
        self.fileName = "";
        self.output = null;
    };

    // 'close' file object without writing to it
    self.closeNoWrite = function () {
        self.fileName = "";
        self.output = null;
    };
};

// This object opens a binary file and writes into the file
OutputBinaryFile = function (fileName, coreId) {
    var self = this;

    // name of the generated file
    self.fileName = fileName;

    // output stream
    self.output = scriptApi.createFile(fileName, coreId, FileType.BINARY);

    // write file content and 'close' file object
    self.close = function (bytes) {
        var numOfBytes = bytes.length;
        var javaByteArray = Java.type("byte[]");
        var javaBytes = new javaByteArray(numOfBytes);
        for (var i = 0; i < numOfBytes; i++) {
            javaBytes[i] = bytes[i];
        }
        self.output.write(javaBytes);
        self.fileName = "";
        self.output = null;
    };

    // 'close' file object without writing to it
    self.closeNoWrite = function () {
        self.fileName = "";
        self.output = null;
    };
};

// Object contains frequently used helper functions for processing arrays, strings and comments
Utils = new function () {
    var self = this;

    // Regex for matching empty strings or strings containing non-printable characters only
    self.emptyStringRegex = new RegExp(/^\s*$/);

    // function creates a string consisting of characters defined by first argument with length defined by second argument (e. g. Utils.makeString('*', 5) will return '*****')
    self.makeString = function (character, count) {
        return Array(count + 1).join(character);
    };

    // function determines, if input string defined by argument contains no printable character (return value will be true for strings "", "  ", "  \n  " etc...)
    self.isEmpty = function (str) {
        return self.emptyStringRegex.test(str);
    };

    // function determines, if input string defined by argument contains at least one printable character (return value will be true for strings "f", "  f", "f  \n  " etc...)
    self.notEmpty = function (str) {
        return !self.isEmpty(str);
    };

    // function trims newlines from the beginning and the end of string
    self.trimNewlines = function (str) {
        return str.replace(/^\n*|\n*$/g, '');
    };

    // function creates and returns usual comment like '/* comment */'
    self.makeComment = function (content) {
        return '/* ' + content + ' */';
    };

    // function creates and returns initialization comment from array of strings defined by content in argument
    self.makeInitComment = function (content) {
        if (self.isEmpty(content)) {
            return "";
        }
        return (
            "/" +
            self.makeString("*", 119) +
            [""].concat(content).join("\n * ") +
            "\n " +
            self.makeString("*", 118) +
            "/"
        );
    };

    // function removes duplicit lines from string defined by argument
    self.removeDuplicitLines = function (str) {
        var linesArray = str.split("\n");
        var uniqueArray = linesArray.filter(function (item, pos) {
            return linesArray.indexOf(item) == pos;
        });
        return uniqueArray.join("\n");
    };

    // function will return an array containing values of object defined by argument (converts associative array to array indexed by numbers)
    self.objectValues = function (o) {
        var keys = Object.keys(o);
        values = [];
        for (var k in keys) {
            values.push(o[keys[k]]);
        }
        return values;
    };

    // function returns indentation string (spaces) of level defined by argument, tab width is set to 2 spaces by default
    self.indent = function (level) {
        var tab = "  ";
        return self.makeString(tab, level);
    };

    // function renders section of generated code consisting of a comment in header of section and its content (C source code - second argument)
    self.renderJsonSection = function (content) {
        if (self.isEmpty(content)) {
            return "";
        } else {
            return content;

        }
    };

    self.renderSection = function (content) {
        if (self.isEmpty(content)) {
            return "";
        } else {
            return content;
        }
    };

    // function wraps input string into clang-off and clang-on directives in order to ignore the fragment code by clang formatter (used for YAML sections)
    self.clangOff = function (str) {
        return self.notEmpty(str) ?
            [self.makeComment('clang-format off'), str, self.makeComment('clang-format on')].join("\n") :
            "";
    };
};

sharedResources = new function () {
    var self = this;
    // global profile object
    self.profile = scriptApi.getProfile();

    // collection of functional groups
    self.functionalGroups = self.profile.getFunctionalGroups();

    // global config set of the system component
    self.globalConfigSetSystem = null;
    if (self.profile.getComponentConfiguration("system") != null) {
        self.globalConfigSetSystem = self.profile.getComponentConfiguration("system").getGlobalConfigSet();
    } else {
        // Error is not reported because it is invalid project configuration provided by the Peripherals tool - the check is a workaround of the Config Tools V9 issue MCUXCON-7117
        //scriptApi.logError("The system component is not available in the project.");
    }

    self.globalConfigSets = [];
    self.profile.getComponentConfigurations().forEach(function (comp) {
        if (comp.getGlobalConfigSet() != null) {
            self.globalConfigSets.push(comp.getGlobalConfigSet());
        }
    });

    // coresList is an array containing list of coreIds of each MCU cores, e. g.: ['core0', 'core1']
    self.coresList = Object.keys(
        JSON.parse(self.profile.getMcuInfo().getCoresList())
    );

    // flag defining, if user selected to generate YAML in GUI
    self.enableYaml = self.profile.getYaml();

    // function returns global YAML of profile together with YAML of global config sets of all components wrapped in clang-off/clang-on directives
    // if generate YAML option is disabled in GUI, returns empty string
    self.getGlobalYaml = function () {
        var componentConfigurations = self.profile.getComponentConfigurations();
        var globalYaml = self.getYaml(self.profile);

        for (var iterator = componentConfigurations.iterator(); iterator.hasNext();) {
            var componentConfiguration = iterator.next();
            globalYaml += componentConfiguration.getGlobalConfigSet() ?
                (self.getYaml(componentConfiguration) != null) ?
                    '\n\n' + self.getYaml(componentConfiguration) :
                    "" :
                "";
        }
        return Utils.clangOff(globalYaml);
    };

    // function checks, if generate YAML option is enabled in GUI and returns YAML section of element (component configuration or profile)
    // if generate YAML option is disabled in GUI, returns empty string
    self.getYaml = function (element) {
        return self.enableYaml ? element.getYaml() : "";
    };
};

// Object maps java ComponentInstance objects and describes all attributes and helper functions needed for generation of code related to components
ComponentDescriptor = function (componentInstance, functionalGroup) {
    var self = this;

    // name of the component
    self.name = componentInstance.getName();

    // prefix of the functional group passed to constructor
    self.prefix = functionalGroup.prefix;

    // YAML describing the component configuration
    self.yaml = Utils.clangOff(sharedResources.getYaml(componentInstance));

    // save peripheral type of the component (for example 'UART', 'ADC', 'DMA' etc...)
    self.peripheralType = (componentInstance.getPeripheral() != null && componentInstance.getMcu().getPeripheralType(componentInstance.getPeripheral()) != null) ? componentInstance.getMcu().getPeripheralType(componentInstance.getPeripheral()).toLowerCase() : 'other';

    self.smYmlFileSections = {
        sm_yml: ""
    };

    // names of C code sections related to the component, which will be generated into user_configuration.json file
    self.UserConfigJsonFileSections = {
        user_config: ""
    };

    // function adds initial comment and component YAML section to initialization C code related to the component configuration (to be used in peripherals.c)
    self.wrap = function (mainContent) {
        return [
            self.yaml,
            mainContent
        ].join("\n");
    };

    self.renderComponentYaml = function () {
        var out = self.wrap(self.smYmlFileSections.sm_yml);
        return out;
    };

    // function fills file sections with corresponding code emitted by java configSet.emit function
    self.processSections = function (configSet, sections) {
        var codeEmitter = configSet.getCodeEmitter();
        for (var sectionId in sections) {
            var codeFragment = codeEmitter.emit(sectionId);
            if (Utils.notEmpty(codeFragment)) {
                sections[sectionId] += codeFragment;
            }
            // process custom section providers (if present)
            var sp = CodeGenerator.getSectionProvider(componentInstance.getType(), sectionId);
            if (sp != null) {
                // add resulting content into the section
                sections[sectionId] += sp.providerFn(componentInstance, sectionId, configSet);
            }
        }
    };

    self.invokeInstanceGenerator = function () {
        var ig = CodeGenerator.getInstanceCodeGenerator(componentInstance);
        if (ig !== null) {
            // invoke generator, passing instance and functional group object
            ig(componentInstance, functionalGroup.getFnGroupObject());
        }
    };

    // if component instance has an error (has not valid configuration), log warning and generate comment with error into peripherals.c file
    // else fill all corresponding peripherals.h and peripherals.c file sections with C code corresponding to the component configuration
    if (componentInstance.getError()) {
        scriptApi.logWarning("Initialization code of  " + self.name + " component in " + functionalGroup.name + " functional group is not generated due to invalid configuration.");
        self.smYmlFileSections.sm_yml = Utils.indent(1) + Utils.makeComment("Configuration of the component " + self.name + " of functional group " + functionalGroup.name + " is not valid.") + '\n';
    } else {
        var configSets = componentInstance.getChildren();
        for (var componentSettingIndex in configSets) {
            self.processSections(configSets[componentSettingIndex], self.smYmlFileSections);
            self.processSections(configSets[componentSettingIndex], self.UserConfigJsonFileSections);
        }
    }
};

// Object maps java FunctionalGroup objects and describes all attributes and helper functions needed for generation of code related to functional groups
FunctionalGroupDescriptor = function (functionalGroup) {
    var self = this;

    // name of the functional group
    self.name = functionalGroup.getName();

    // prefix of the functional group
    self.prefix = functionalGroup.getIdPrefix();

    // flag defining, if the functional group should be called from BOARD_InitBootPeripherals() function
    self.isCalledFromDefaultInit = functionalGroup.isCalledFromDefaultInit();

    // Optional user's functional group description (to be used in the group init. function in defintion and declaration 
    self.descriptionDefinition = (functionalGroup.getDescription() != "") ? ("/*!\n * brief " + functionalGroup.getDescription().replace(/\n/g, "\n * ") + "\n */") : "";
    self.descriptionDeclaration = (functionalGroup.getDescription() != "") ? ("/*!\n * @brief " + functionalGroup.getDescription().replace(/\n/g, "\n * ") + "\n */") : "";

    self.getFnGroupObject = function () {
        return functionalGroup;
    };

    // empty list of component instances corresponding to the functional group - will be filled with ComponentDescriptor objects
    self.components = [];

    self.renderYaml = function () {
        var components = self.components
            .map(function (component) { return component.renderComponentYaml(); })
            .join("\n\n");
        return Utils.renderSection(components);
    };

    self.getUserConfigJsonFileSection = function (sectionId, comment) {
        var sectionCode = self.components
            .map(function (component) { return component.UserConfigJsonFileSections[sectionId]; })
            .join("");

        return ((Utils.notEmpty(comment) && Utils.notEmpty(sectionCode)) ? Utils.makeComment(comment) + '\n' : "") + sectionCode;
    };
    // function returns an object of processed C code sections for user_configuration.json file related to the functional group
    self.getUserConfigJsonFileSections = function () {
        return {
            user_config: self.getUserConfigJsonFileSection("user_config", "")
        };
    };

    self.invokeInstanceGenerators = function () {
        self.components.forEach(
            function (comp) {
                comp.invokeInstanceGenerator();
            }
        );
    };

    // Main initialization
    // get functional group component instances from scriptAPI
    var componentInstances = functionalGroup.getComponentInstances();
    // map scriptAPI component instances objects to ComponentDescriptor objects and fill components list with them
    for (var componentInstanceIndex in componentInstances) {
        self.components.push(new ComponentDescriptor(componentInstances[componentInstanceIndex], self));
    }
};

// functional groups will be filled from main() function for each core separatelly
// TODO - refactor and remove this
var functionalGroupsMapper;

// Object maps functional groups corresponding to core defined by argument into a list of FunctionalGroupDescirptor objects
FunctionalGroupsMapper = function (coreId) {
    var self = this;

    // empty list of functional group instances corresponding to the core - will be filled with FunctionalGroupDescirptor objects
    self.functionalGroups = [];

    // function maps scriptAPI functional group objects to FunctionalGroupDescriptor objects and fills functionalGroups list with them
    self.processFunctionalGroups = function () {
        var functionalGroupsInstances = sharedResources.functionalGroups;
        for (var functionalGroupIndex in functionalGroupsInstances) {
            var functionalGroup = functionalGroupsInstances[functionalGroupIndex];
            if (functionalGroup.getCore() == coreId) {
                self.functionalGroups.push(new FunctionalGroupDescriptor(functionalGroup));
            }
        }
    };

    /** Invokes custom code generators (if present)
     * @returns {undefined}
     */
    self.invokeInstanceGenerators = function () {
        self.functionalGroups.forEach(
            function (fg) {
                fg.invokeInstanceGenerators();
            }
        );
        return;
    };

    // map scriptAPI functional group objects to FunctionalGroupDescriptor objects and fill functionalGroups list with them
    self.processFunctionalGroups();
};

smYamlFileDescriptor = function () {
    var self = this;

    self.wrap = function (mainContent) {
        var strWrap = ((mainContent != "") ?
            [
                mainContent,
            ].join("\n")
            :
            "");
        return strWrap;
    };

    self.render = function () {

        var global_yaml = sharedResources.getGlobalYaml();

        var component_yaml = functionalGroupsMapper.functionalGroups.map(function (functionalGroup) {
            return functionalGroup.renderYaml();
        });

        output = self.wrap(
            [
                global_yaml,
                component_yaml,
            ]
                .filter(Utils.notEmpty)
                .join("\n\n")
        );
        return output;
    };
};

// Object assembles parts of user_configuration.json file
UserConfigJsonFileDescriptor = function () {
    var self = this;

    // string containing an initial part of json file
    self.head = '{';

    // string containing a closing part of json file
    self.tail = '}';

    // function adds a notification, initial and closing parts of the json file content (defined by argument) and returns wrapped content of the file
    self.wrap = function (mainContent) {
        var strWrap = ((mainContent != "") ?
            [
                //self.head,
                mainContent,
                //self.tail
            ].join("\n")
            :
            "");
        return strWrap;
    };

    // function collects all code fragments in sections of the RTE_Device.h file from functional groups mapper array and returns final content of the file
    self.render = function () {
        // collect all sections of the RTE_Device.h file from all functional groups, then group the same sections from all functional groups
        var sectionsArray = functionalGroupsMapper.functionalGroups.map(function (functionalGroup) {
            return functionalGroup.getUserConfigJsonFileSections();
        });

        // group driver_includes directives from all functional groups
        var user_config = sectionsArray
            .map(function (functionalGroupSection) { return functionalGroupSection.user_config; })
            .filter(Utils.notEmpty)
            .join("\n");

        // assembly collected sections and return final content of the RTE_Device.h file
        output = self.wrap(
            [
                Utils.renderJsonSection(user_config),
            ]
                .filter(Utils.notEmpty)
                .join(",\n")
        );
        return output;
    };
};

ConfigDataUtils = new function () {
    /** Method returning list of functional groups for given core
     * @param coreID - Identifier of the core
     * @returns Array of functional group objects
     */
    this.fnGroupsForCore = function (coreID) {
        var output = [];
        var fnGroups = sharedResources.functionalGroups;
        for (var functionalGroupIndex in fnGroups) {
            var functionalGroup = fnGroups[functionalGroupIndex];
            if (functionalGroup.getCore() === coreID) {
                output.push(functionalGroup);
            }
        }
        return output;
    };
};

var _currentComponent = null; // global variable tracking which component is initialized
var _currentScriptFolder = null;

// singleton CodeGenerator object
var CodeGenerator = new function () {
    var self = this;
    // array of custom generators
    var fileGenerators = [];
    var sectionProviders = [];
    var instanceGenerators = [];

    /** Registers new custom file generator
     * Use this in case of generating fixed file independent on number 
     * or presence instances of the instances.
     * @param filePath - relative path to the generated file
     * @param fileGeneratorFn - function returning content of the file
     */
    self.registerFileGenerator = function (filePath, fileGeneratorFn) {
        fileGenerators.push({
            filePath: filePath,
            genFn: fileGeneratorFn
        });
        return;
    };

    /* register function providing custom content for section. This provider 
     * will be invoked every for every instance when the content is needed.
     * 
     * @param  sections - array of section ids, handled by the provider
     * @param providerFn - function returning string with section content
     */
    self.registerSectionProvider = function (sections, providerFn) {
        // create empty array for this component if it hasn't any provider
        if (sectionProviders[_currentComponent] == null) {
            sectionProviders[_currentComponent] = [];
        }
        sections.forEach(
            function (section) {
                sectionProviders[_currentComponent][section] =
                {
                    sectionId: section,
                    providerFn: providerFn
                };
            }
        );
        return;
    };
    /** Returns section provider for given component and section
     * 
     * @param component type ID
     * @param sectionId
     * @returns {CodeGenerator.codegeneratorCodeGenerator.getSectionProvider.out}
     */
    this.getSectionProvider = function (component, sectionId) {
        var out = null;
        if (sectionProviders[component] !== undefined) {
            out = sectionProviders[component][sectionId];
            if (out === undefined) {
                out = null;
            }
        }
        return out;
    };

    /** Registers function called for every instance of the component
     * This function has to completely handle file creation and content writing itself
     * 
     * @param instanceGeneratorFn - function to be called with 2 paramters: instance and functional group objects
     */
    this.registerInstanceCodeGenerator = function (instanceGeneratorFn) {
        instanceGenerators[_currentComponent] = instanceGeneratorFn;
        return;
    };

    this.getInstanceCodeGenerator = function (componentInstance) {
        var out = null;
        if (componentInstance !== null && instanceGenerators[componentInstance.getType()] !== undefined) {
            out = instanceGenerators[componentInstance.getType()];
        }
        return out;
    };

    /** Launches all custom scripts for all used components allowing them
     * to register custom file generator(s).
     */
    this.launchUsedComponentScripts = function () {
        var profile = scriptApi.getProfile();
        var components = profile.getComponentConfigurations();
        components.forEach(
            function (c) {
                if (c.getId() !== 'system') {
                    var scriptfile = c.getScriptFile();
                    if (scriptfile !== "") {
                        _currentComponent = c.getId();
                        // remove filename from folder
                        _currentScriptFolder = scriptfile.replace(/[^\\\/]*$/, "");
                        // load and execute script
                        scriptApi.requireScript(scriptfile);
                    }
                }
            }
        );
        _currentComponent = null;
    };

    /** generates content of all files for given core by executing file 
     * generator functions.
     * 
     * @param coreId - ID of the core
     */
    this.generateAllFiles = function (coreId) {

        fileGenerators.forEach(
            function (fg) {
                var output = fg.genFn();
                if (output !== null) {
                    new OutputFile(fg.filePath, coreId).close(output);
                }
            }
        );
    };

};


// main function will iterate over all MCU cores, creates list of corresponding functional groups and if it is not empty, generates peripherals.c/.h source files
function main() {

    // Load and execute custom scripts
    CodeGenerator.launchUsedComponentScripts();

    if (sharedResources.globalConfigSetSystem != null) {
        // iterate cores
        for (var coreIndex = 0; coreIndex < sharedResources.coresList.length; coreIndex++) {
            var coreId = sharedResources.coresList[coreIndex];
            // prepare FunctionalGroupDescriptor objects only for current core
            // TODO - refactor to remove it as global variable
            functionalGroupsMapper = new FunctionalGroupsMapper(coreId);
            if (functionalGroupsMapper.functionalGroups.length > 0) {
                // YAML placeholder
                // new OutputFile("sm.yaml", coreId).close(new smYamlFileDescriptor().render());
                var user_json_body = new UserConfigJsonFileDescriptor().render();
                if (user_json_body != "") {
                    new OutputFile("user_configuration.json", coreId).close(user_json_body);
                    var map = scriptApi.getProfile().generateSourceFiles();
                    for (var entry of map.entrySet()) {
                        new OutputFile("../configs/" + scriptApi.getMexFileName() + "/" + entry.getKey(), coreId).close(entry.getValue());
                    }
                }
            }
            // generate all custom files content
            CodeGenerator.generateAllFiles(coreId);
            // invoke custom instance generators of components
            functionalGroupsMapper.invokeInstanceGenerators();
        }
    }
}

// generation script entry point
main();